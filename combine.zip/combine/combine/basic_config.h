#ifndef __BASIC_CONFIG_h__
#define __BASIC_CONFIG_h__
  #define SCREEN_WIDTH 128 // OLED display width, in pixels
  #define SCREEN_HEIGHT 64 // OLED display height, in pixels
  // Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
  #define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
  Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
    
  #define NUMFLAKES     10 // Number of snowflakes in the animation example
  
  #define LOGO_HEIGHT   16
  #define LOGO_WIDTH    16

  // application config
  #define BAUD_RATE 57600
  /* BAUD RATE depends on the arduino's bootloader's BAUD RATE
      arduino nano old bootloader's baud rate is 57600  */
  // if the bonjour support is turned on, then use the following as the name
 
  
  // serial end ethernet buffer size
  #define BUFFER_SIZE 128
  
  // hardware config
  #define WIFI_LED  2
  //#define CONNECTION_LED 16
  #define TX_LED  13
  #define RX_LED  15
  //download paragrame to arduino mega2560 parameter
  #define ADO_RST  14 //Arduino reset
  
  // #define SOFT_RESET  16 //ESP reset
  // comment out the following line to enable DHCP
  #define STATIC_IP

  #ifdef STATIC_IP
    // change the IP address and gateway to match your network

    #define GATEWAY_ADDRESS "192.168.1.1"
    #define NET_MASK "255.255.255.0"
  #endif

#endif
